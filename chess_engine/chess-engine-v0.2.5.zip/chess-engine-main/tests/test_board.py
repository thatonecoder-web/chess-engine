from chess_engine.board import Board
from chess_engine.moves import Move


def test_board_generates_and_parses_the_initial_fen_round_trip():
    board = Board()
    fen = board.to_fen()

    assert fen == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    loaded = Board()
    loaded.from_fen(fen)

    assert loaded.turn == "white"
    assert loaded.castling_rights == "KQkq"
    assert loaded.en_passant_target is None


def test_board_creation():
    board = Board()

    assert board.board[6][0].symbol == "P"
    assert board.board[7][4].symbol == "K"
    assert board.board[1][0].symbol == "p"
    assert board.turn == "white"


def test_move_piece():
    board = Board()

    move = Move("e2", "e4")

    assert board.make_move(move) is True
    assert board.board[6][4] is None
    assert board.board[4][4].symbol == "P"


def test_turn_switches():
    board = Board()

    board.make_move(Move("e2", "e4"))

    assert board.turn == "black"

    board.make_move(Move("e7", "e5"))

    assert board.turn == "white"


def test_cannot_move_empty_square():
    board = Board()

    move = Move("e4", "e5")

    assert board.make_move(move) is False


def test_cannot_move_opponents_piece():
    board = Board()

    move = Move("e7", "e5")

    assert board.make_move(move) is False


def test_cannot_capture_own_piece():
    board = Board()

    move = Move("e2", "e1")

    assert board.make_move(move) is False